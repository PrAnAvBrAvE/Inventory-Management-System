# Inventory-Management-System-Web-application-using-HTML-CSS-JavaScript-JSP-MYSQL
I have developed Online Inventory Management System using HTML, CSS, JavaScript, JSP, MYSQL. I have provided login for admin. Admin will be able to manage customer details. I have created system for 4 category products which includes laptops, tv, sound and mobile. Admin can add any product of this 4 categories. He/she will be able to update product details, search product details, delete product details, etc., In short everything related to store will be managed.<br/>
Click on image to watch on youtube.<br/>
[![Watch the video](https://img.youtube.com/vi/SFFTAX6LGJ4/maxresdefault.jpg)](https://youtu.be/SFFTAX6LGJ4)</center>
